//This is my own code that I wrote out without instruction help to demonstrate my understanding of concepts

//import java.util.Date;
//import java.text.DateFormat;
//import java.text.NumberFormat;
//
//public class TestHotel {
//    public static void main(String[] args) {
//
//        //Formatting
//        NumberFormat nf = NumberFormat.getCurrencyInstance();
//
//        //Object Creation and Calculation
//        Hotel customer1 = new Hotel("10 - A");
//        customer1.calculate();
//        Hotel customer2 = new Hotel("12 - B", 3);
//        customer2.calculate();
//        Hotel customer3 = new Hotel("14 - C", 5, 3);
//        customer3.calculate();
//
//        //Customer 1 Displays
//        display1(customer1, nf);
//
//        //Customer 2 Displays
//        display1(customer2, nf);
//
//        //Customer 3 Displays
//        display1(customer3, nf);
//
//        //Customer 1 adds Guest and Night
//        System.out.println();
//        System.out.println("\tAdd 3 Nights and 1 Guest");
//        customer1.addNights(3);
//        customer1.addGuest(1);
//        customer1.calculate();
//        display1(customer1, nf);
//
//        //Summary Display
//        display2(customer1,customer2,customer3,nf);
//    }
//
//    static void display1(Hotel hotel, NumberFormat nf) {
//        System.out.println();
//        System.out.println("\tThe XYZ Cheap Lodging Inc.");
//        Date d = new Date();
//        DateFormat df = DateFormat.getDateInstance();
//        System.out.println("\tDate:\t" + df.format(d));
//        System.out.println("Room #:\t\t\t\t" + hotel.getRoomNumber());
//        System.out.println("Room Cost:\t\t\t" + nf.format(Hotel.getRoomRate()));
//        System.out.println("Length of Stay:\t\t" + hotel.getNoOfNights());
//        System.out.println("No. of Guests:\t\t" + hotel.getNoOfGuests());
//        System.out.println("Tax of 6.5%:\t\t" + nf.format(hotel.getTax()));
//        System.out.println("\t Subtotal:\t\t\t" + nf.format(hotel.getSubtotal()));
//        System.out.println("Telephone:\t\t\t" + nf.format(Hotel.getTelephone()));
//        System.out.println("Meal Charges:\t\t" + nf.format(hotel.getMeal()));
//        System.out.println("Tip:\t\t\t\t" + nf.format(hotel.getTip()));
//        System.out.println("TOTAL AMOUNT DUE:\t......." + nf.format(hotel.getTotal()));
//        System.out.println("Thanks for Staying at XYZ Cheap Lodging Inc.");
//        System.out.println("\t\t Please Come Again!!!");
//    }
//    //Summary Display Statement
//    static void display2(Hotel customer1, Hotel customer2, Hotel customer3,NumberFormat nf) {
//        System.out.println();
//        System.out.println("\tOFFICIAL USE ONLY");
//        System.out.println("\tToday's Summary");
//        System.out.println("Room\t\t\t\t...." + nf.format(customer1.getAmountDue() + customer2.getAmountDue() + customer3.getAmountDue()));
//        System.out.println("Telephone\t\t\t...." + nf.format(3 * Hotel.getTelephone()));
//        System.out.println("Meal\t\t\t\t...." + nf.format(customer1.getMeal() + customer2.getMeal() + customer3.getMeal()));
//        System.out.println("Tips\t\t\t\t...." + nf.format(customer1.getTip() + customer2.getTip() + customer3.getTip()));
//        System.out.println("Tax\t\t\t\t\t...." + nf.format(customer1.getTax() + customer2.getTax() + customer3.getTax()));
//        System.out.println("-----------------------------");
//        System.out.println("Gross Transaction\t...." + nf.format(customer1.getTotal() + customer2.getTotal() + customer3.getTotal()));
//    }
//}
