public class Hotel {

    //Class Variables (Constants) Same for every object
    private static final double roomRate = 79.95,
                                taxRate = 6.5,
                                telephone = 5.75,
                                mealCost = 12.95,
                                tipRate = .075;

    //Instance Variables
    private int noOfNights,
                noOfGuests;
    private double amountDue,
                   meal,
                   tax,
                   subtotal,
                   total,
                   tip,
                   telephoneTotal;
    private String roomNumber;

    //Overloaded Constructors (decoupled)
    public Hotel(String room){
        this.roomNumber = room;
        noOfGuests = 1;
        noOfNights = 1;
    }
    public Hotel(String room, int nights){
        this.roomNumber = room;
        this.noOfNights = nights;
        this.noOfGuests = 1;
    }
    public Hotel(String room, int nights, int guests){
        this.roomNumber = room;
        this.noOfNights = nights;
        this.noOfGuests = guests;
    }

    //Getters / Accessor Methods for Constant class variables (I know some aren't used, but its good convention)
    public static final double getRoomRate(){return roomRate;}
    public static final double getTaxRate(){return taxRate;}
    public static final double getTelephone(){return telephone;}
    public static final double getMealCost(){return mealCost;}
    public static final double getTipRate(){return tipRate;}

    //Getters / Accessor Methods for Instance variables
    public int getNoOfNights(){return noOfNights;}
    public int getNoOfGuests(){return noOfGuests;}
    public double getAmountDue(){return amountDue;}
    public double getMeal(){return meal;}
    public double getTax(){return tax;}
    public double getSubtotal(){return subtotal;}
    public double getTotal(){return total;}
    public double getTip(){return tip;}
    public double getTelephoneTotal(){return telephoneTotal;}
    public String getRoomNumber(){return roomNumber;}

    //Setters / Methods for calculation
    public void addNights(int nights){
        this.noOfNights += nights;
    }
    public void addGuest(int guests){
        this.noOfGuests += guests;
    }

    public void calculate(){
        amountDue = roomRate * noOfNights * noOfGuests;
        tax = amountDue * taxRate/100;
        subtotal = amountDue + tax;
        meal = mealCost * noOfNights * noOfGuests;
        tip = tipRate *(subtotal + meal + telephone);
        //line 70 is needed in order to calculate total telephone as you can't add them together on line 68 in test class
        telephoneTotal = telephone;
        total = subtotal + telephone + meal + tip;
    }


}

